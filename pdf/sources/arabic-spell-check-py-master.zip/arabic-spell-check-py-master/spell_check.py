from spellchecker import SpellChecker

spell = SpellChecker(language='ar')  # Spanish dictionary
print(spell['السلام'])
